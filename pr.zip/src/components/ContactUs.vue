<template>
  <div class="contact-us wrapper">
    <div class="content contact-us__content">

      <div class="title contact-us__title">Contact us</div>

      <form class="form" @submit.prevent="">

        <input class="input" type="text" placeholder="Name">

        <input class="input" type="text" placeholder="Email">

        <input class="input" type="text" placeholder="Subject">

        <textarea class="input input-margin" placeholder="Your message"></textarea>

        <input class="submit" type="submit" value="SUBMIT">

      </form>

    </div>
  </div>
</template>

<script>
export default {
  name: "ContactUs"
}
</script>

<style lang="scss">
@import "../assets/styles/variables";

.contact-us {
  height: 100vh;
  padding-top: 110px;

  &__content {
    flex-direction: column;
    justify-content: center;
  }

  &__title{
    color: rgb( 65, 61, 75 );
    margin-bottom: 70px;
  }
}

.form {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 25px;
}

.input {
  width: 700px;
  height: 65px;
  border-radius: 5px;
  border-width: 0.035cm;
  border-color: rgb(0, 0, 0);
  border-style: solid;
  opacity: 0.202;
  box-sizing: border-box;
  padding-left: 20px;
  font-size: 20px;
  font-family: "Times New Roman";
}

.input::placeholder {
  font-size: 20px;
  font-family: "Times New Roman";
  color: $footer-bg;
  opacity: 0.702;
}

.input-margin{
  padding-top: 19px;
  height: 259px;
}

.submit {
  font-size: 0.564cm;
  font-family: "Roboto";
  color: $blue-color;
  text-align: center;

  border-width: 0.035cm;
  border-color: rgb(0, 224, 208);
  border-style: solid;
  border-radius: 0.071cm;

  width: 4.233cm;
  height: 1.411cm;
}

</style>