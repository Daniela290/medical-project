<template>
  <div class="navbar wrapper">

    <div class="content navbar__content">

      <div class="text-wrapper">

        <div class="logo">
          <span class="logo__first-letter">M</span>
          <span class="logo__other-letters">EDICAL</span>
        </div>

        <div class="navigation">
          <div v-for="(el,index) of navigationEL"
               :key="index"
               class="text navbar__text"
          @click="clickHandler()">
            {{ el.tittle }}
          </div>
        </div>

      </div>

      <button class="btn navbar__btn">GET STARTED</button>

    </div>

  </div>
</template>

<script>
export default {
  name: "Navbar",
  data() {
    return {
      navigationEL: [{tittle: 'Home', isActive: false, el: '#home'},
        {tittle: 'About us', isActive: false, el: '#aboutUs'},
        {tittle: 'Services', isActive: false, el: '#futures'},
        {tittle: 'Portfolio', isActive: false, el: '#portfolio'},
        {tittle: 'Blog', isActive: false, el: '#contactUs'},
        {tittle: 'Contacts', isActive: false, el: '#contactUs'}],
    }
  },
  methods:{
    clickHandler(){}
  }

}
</script>

<style lang="scss">
@import "../assets/styles/variables";

.navbar {
  background: rgba($portfolio-bg, .6);
  height: 106px;
  position: fixed;
  z-index: 10;
  top: 0;
  left: 0;

  &__text {
    color: $dark-color;
    position: relative;
  }

  &__text:hover:before {
    //transform: scaleX(1);
    width: 100%;
    left: 0;
  }


  &__text::before {
    content: '';
    position: absolute;
   // transform: scaleX(0);
    height: 2px;
    bottom: 0;
   // width: 100%;
    width: 0;
    right: 0;
    background-color: $dark-color;
    transition: .3s linear;
  }

  &__btn {
    color: rgb(255, 255, 255);
    background-color: $blue-color;
    width: 4.939cm;
  }

  &__content {
    justify-content: space-between;
  }
}

.navigation {
  display: flex;
  align-items: center;
  gap: 38px;
}

.logo {
  font-size: 0.847cm;
  font-family: "Roboto";
  font-weight: bold;
  line-height: 1.249;

  &__first-letter {
    color: $blue-color;
  }

  &__other-letters {
    color: $dark-color;
  }
}

</style>