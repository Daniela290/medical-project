<template>
  <div>
    <Navbar/>
    <Header/>
    <ContactUs/>
  </div>
</template>

<script>
import Navbar from "@/components/Navbar";
import Header from "@/components/Header";
import ContactUs from "@/components/ContactUs";

export default {
  name: 'App',
  components: {ContactUs, Header, Navbar},
}
</script>

<style lang="scss">
@import "assets/styles/index";
</style>
